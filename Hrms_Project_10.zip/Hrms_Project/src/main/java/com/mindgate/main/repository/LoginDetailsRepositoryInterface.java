package com.mindgate.main.repository;

import com.mindgate.main.domain.LoginDetails;

public interface LoginDetailsRepositoryInterface {

	
 LoginDetails getUser(LoginDetails loginDetails);

 public boolean addLogin(LoginDetails loginDetails);
}
