package com.mindgate.main.service;

import com.mindgate.main.domain.LoginDetails;

public interface LoginDetailsServiceInterface {

	 public LoginDetails getUser(LoginDetails loginDetails);

	 public boolean addLogin(LoginDetails loginDetails);

}
